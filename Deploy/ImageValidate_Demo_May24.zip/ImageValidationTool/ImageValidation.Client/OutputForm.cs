﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Windows.Forms;

namespace ImageValidation.Client
{
    public partial class OutputForm : Form
    {
        private HtmlAssembler html_assembler;
        private string filename;

        public OutputForm()
        {
            InitializeComponent();
            init();
        }

        public OutputForm(string filename)
        {
            InitializeComponent();
            init();
            this.filename = filename;

            showHtmlOutput();
        }

        private void init()
        {
            textBox1.Size = new System.Drawing.Size(584, 537);
            webBrowser1.Size = new System.Drawing.Size(584, 537);
            textBox1.ReadOnly = true;
            html_assembler = new HtmlAssembler();
        }

        private void showHtmlOutput()
        {
            textBox1.Hide();
            webBrowser1.Visible = true;
            webBrowser1.Location = new System.Drawing.Point(0, 0);
            webBrowser1.DocumentText = html_assembler.readFileToHtml(this.filename);
        }

        private void showOutput()
        {
            showHtmlOutput();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            showOutput();
        }
        static IEnumerable<string> ReadLines(TextReader r)
        {
            string line;
            while ((line = r.ReadLine()) != null)
            {
                if (line.Length > 0)
                {
                    yield return line;
                }
            }
        }

        private void exportBtn_Click(object sender, EventArgs e)
        {
            string filename = @"../../Report/ImageReport.csv";
            string[] lines = File.ReadAllLines(filename);

            string[] headers = lines[0].Split(',').Select(x => x.Trim('\"')).ToArray();

            //lines = (string[]) lines.Skip(1);

            var xml = new XElement("TopElement",
   lines.Select(line => new XElement("Item",
      line.Split(';')
          .Select((column, index) => new XElement("Column" + index, column)))));

            xml.Save(@"../../Report/Image_DetailedReport.xml");

          
             
        }
    }
}

param($installPath, $toolsPath, $package, $project)

$project.DTE.ItemOperations.Navigate('http://wpftoolkit.codeplex.com/wikipage?title=Extended%20WPF%20Toolkit%20Plus')
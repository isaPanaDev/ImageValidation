﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdminWebPortal.Models
{
    public class HotFixModel
    {
        public List<HotFix> HotFix { get; set; }
    }
}
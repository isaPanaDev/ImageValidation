﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdminWebPortal.Models
{
    public class GetAllUsers
    {
        public List<User> User { get; set; }
    }
}